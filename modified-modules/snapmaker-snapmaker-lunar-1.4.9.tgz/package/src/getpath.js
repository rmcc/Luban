var path = require('path')
var os = require('os')
var fs = require('fs')

const lunarPlatformPathMap = {
    'darwin': {
        'Slicer': '../engine/MacOS/LunarSlicer',
        'TPP': '../engine/MacOS/LunarTPP',
        'MP': '../engine/MacOS/LunarMP'
    },
    'linux': {
        'Slicer': '../engine/Linux/LunarSlicer',
        'TPP': '../engine/Linux/LunarTPP',
        'MP': '../engine/Linux/LunarMP'
    },
    'win32': {
        'Slicer': '../engine/Windows-x64/LunarSlicer.exe',
        'TPP': '../engine/Windows-x64/LunarTPP.exe',
        'MP': '../engine/Windows-x64/LunarMP.exe'
    }
}

function getPlatformPath(engine) {
    var platform = process.env.npm_config_platform || os.platform()
    if (lunarPlatformPathMap[platform] && lunarPlatformPathMap[platform][engine]) {
        return lunarPlatformPathMap[platform][engine];
    } else {
        throw new Error('Lunar builds are not available on platform: ' + platform);
    }
}

function getPath(engine) {
    var lunarEngine = path.join(__dirname, getPlatformPath(engine));
    if (fs.existsSync(lunarEngine)) {
        return lunarEngine;
    } else {
        throw new Error('Luban Engine path failed. ' + lunarEngine)
    }
}

module.exports = getPath;
