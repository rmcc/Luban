var {Slicer, SLICE_LASER, SLICE_CNC, MODEL_SUPPORT, MODEL_REPAIR, MODEL_CHECK, MODEL_SIMPLIFY} = require("./slicer.js");
var getpath = require("./getpath.js");

var slice = function (type, inputPath, outputPath, settingsPath) {
    var slice = new Slicer(type, inputPath, outputPath, settingsPath);
    return slice;
}

var slice3DP = function (inputPath, outputPath, settingsPath) {
    var slice = new Slicer(SLICE_LASER, inputPath, outputPath, settingsPath);
    return slice;
}

var sliceLaser = function (inputPath, outputPath, settingsPath) {
    var slice = new Slicer(SLICE_LASER, inputPath, outputPath, settingsPath);
    return slice;
}

var sliceCNC = function (inputPath, outputPath, settingsPath) {
    var slice = new Slicer(SLICE_CNC, inputPath, outputPath, settingsPath);
    return slice;
}

var modelSupport = function (inputPath, outputPath, settingsPath) {
    var slice = new Slicer(MODEL_SUPPORT, inputPath, outputPath, settingsPath);
    return slice;
}

var modelRepair = function (inputPath, outputPath, settingsPath) {
    console.log('modelRepair');
    var slice = new Slicer(MODEL_REPAIR, inputPath, outputPath, settingsPath);
    return slice;
}

var modelCheck = function (inputPath, outputPath, settingsPath) {
    var slice = new Slicer(MODEL_CHECK, inputPath, outputPath, settingsPath);
    return slice;
}

var modelSimplify = function (inputPath, outputPath, settingsPath) {
    var slice = new Slicer(MODEL_SIMPLIFY, inputPath, outputPath, settingsPath);
    return slice;
}

module.exports = {
    SLICE_LASER: SLICE_LASER,
    SLICE_CNC: SLICE_CNC,
    slice: slice,
    sliceLaser, sliceLaser,
    sliceCNC, sliceCNC,
    modelSupport, modelSupport,
    modelRepair, modelRepair,
    modelCheck, modelCheck,
    modelSimplify, modelSimplify,
    getPath: getpath
}
