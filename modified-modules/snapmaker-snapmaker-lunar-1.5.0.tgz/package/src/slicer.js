var fs = require("fs");
var childProcess = require("child_process");
var getpath = require("./getpath.js");

var SLICE_3DP = "3dp";
var SLICE_LASER = "laser";
var SLICE_CNC = "cnc";
var MODEL_SUPPORT = "model_support";
var MODEL_REPAIR = "model_repair";
var MODEL_CHECK = "model_check";
var MODEL_SIMPLIFY = "model_simplify";

var loop = function () {

};

class Slicer {

    constructor(type, inputPath, outputPath, settingsPath) {
        this.sliceType = type;
        this.inputPath = inputPath;
        this.outputPath = outputPath;
        this.settingsPath = settingsPath;


        this.process = null;

        this.events = {};

        this.stdoutEvents = {};
        this.stderrEvents = {};

        this.result = {
            code: 0,
            status: 0,
            msg: ""
        };
    }

    slice() {
        console.log('slice ()');
        this.result = {
            code: 0,
            status: 0,
            msg: ""
        };
        let slice;
        let engine;
        if (this.sliceType === SLICE_3DP) {
            slice = "slice";
            engine = 'Slicer';
        } else if (this.sliceType === MODEL_SUPPORT) {
            slice = "support"
            engine = 'Slicer';
        } else if (this.sliceType === SLICE_LASER) {
            slice = "slicelaser";
            engine = 'TPP';
        } else if (this.sliceType === SLICE_CNC) {
            slice = "slicecnc";
            engine = 'TPP';
        } else if (this.sliceType === MODEL_REPAIR) {
            slice = "modelrepair";
            engine = 'MP';
        } else if (this.sliceType === MODEL_CHECK) {
            slice = "modelcheck";
            engine = 'MP';
        } else if (this.sliceType === MODEL_SIMPLIFY) {
            slice = "modelsimplify";
            engine = 'MP';
        }
        var args;
        if (this.settingsPath) {
            args = [slice, "-v", "-p", "-j", this.settingsPath, "-l", this.inputPath, "-o", this.outputPath];
        } else {
            args = [slice, "-v", "-p", "-l", this.inputPath, "-o", this.outputPath];
        }
        this.process = childProcess.spawn(
            getpath(engine),
            args
        )
        console.log('cmd: ' + getpath(engine) + ' ' + args.join(' '));
        return this;
    }

    type(type) {
        this.sliceType = type;
        return this;
    };

    settings(settingsPath) {
        this.settingsPath = settingsPath;
        return this;
    }

    input(inputPath) {
        this.inputPath = inputPath;
        return this;
    }

    output(outputPath) {
        this.outputPath = outputPath;
        return this;
    }

    on(key, fn) {
        this.events[key] = fn;
        return this;
    }

    onStderr(key, fn) {
        if (key === 'data') {
            this.stderrEvents['data'] = (data) => {
                const array = data.toString().split('\n');
                for (const str of array) {
                    this.getResult(str);
                    fn(str);
                }
            };
        } else {
            this.stderrEvents[key] = fn;
        }
        return this;
    }

    onStdout(key, fn) {
        if (key === 'data') {
            this.stdoutEvents['data'] = (data) => {
                const array = data.toString().split('\n');
                for (const str of array) {
                    this.getResult(str);
                    fn(str);
                }
            };
        } else {
            this.stdoutEvents[key] = fn;
        }
        return this;
    }

    getResult(str) {
        if (str.indexOf('Status') !== -1) {
            this.result.status = str.split(':')[1] ? parseInt(str.split(':')[1].trim()) : 0;
        }
        if (str.indexOf('Message') !== -1) {
            this.result.msg = str.split(':')[1] ? str.split(':')[1].trim() : '';
        }
    }

    end(fn = loop) {
        if (!this.process) {
            this.slice();
        }
        for (const key of Object.keys(this.events)) {
            if (typeof this.events[key] !== "function") {
                continue;
            }
            this.process.on(key, this.events[key]);
        }
        for (const key of Object.keys(this.stdoutEvents)) {
            if (typeof this.stdoutEvents[key] !== "function") {
                continue;
            }
            this.process.stdout.on(key, this.stdoutEvents[key]);
        }
        for (const key of Object.keys(this.stderrEvents)) {
            if (typeof this.stderrEvents[key] !== "function") {
                continue;
            }
            this.process.stderr.on(key, this.stderrEvents[key]);
        }
        this.process.on('close', (code, signal) => {
            let codeErrorMsg = {
                '1': 'Failed to load model',
                '2': 'Error for Settings'
            }

            if (code === null) {
                this.result.code = 139;
                this.result.msg = signal;
            } else {
                this.result.code = code
                this.result.msg = codeErrorMsg[code] || signal;
            }
            if (code === 0) {
                fn(null, this.result);
            } else {
                fn(this.result, null);
            }
        })
    }
}

module.exports = {
    Slicer,
    SLICE_3DP,
    SLICE_LASER,
    SLICE_CNC,
    MODEL_SUPPORT,
    MODEL_REPAIR,
    MODEL_CHECK,
    MODEL_SIMPLIFY
};
