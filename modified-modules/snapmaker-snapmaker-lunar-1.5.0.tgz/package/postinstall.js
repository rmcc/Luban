var fs = require('fs')
var path = require('path')
var os = require('os')

function getOtherPlatformDirPaths() {
    var platform = process.env.npm_config_platform || os.platform()
    switch (platform) {
        case 'darwin':
            return ["engine/Windows-x64", "engine/Linux"]
        case 'linux':
            return ["engine/MacOS", "engine/Windows-x64"]
        case 'win32':
            return ["engine/MacOS", "engine/Linux"]
        default:
            throw new Error('LubanEngine builds are not available on platform: ' + platform)
    }
}

var otherPlatformDirPaths = getOtherPlatformDirPaths();

fs.stat('no-postinstall.txt', (err, stat) => {
    if (!stat) {
        for (let i = 0; i < otherPlatformDirPaths.length; i++) {
            try {
                var otherPlatformDirPath = path.join(__dirname, otherPlatformDirPaths[i]);
                console.log("Remove other platform engine files. " + otherPlatformDirPath);
                if (otherPlatformDirPath.includes("node_modules/snapmaker-luban-engine") !== -1 && fs.existsSync(otherPlatformDirPath)) {
                    var files = fs.readdirSync(otherPlatformDirPath);
                    if (files.length > 0) {
                        for (let i = 0; i < files.length; i++) {
                            var filePath = `${otherPlatformDirPath}/${files[i]}`;
                            if (fs.statSync(filePath).isFile()) {
                                fs.unlinkSync(filePath);
                            }
                        }
                    }
                    fs.rmdirSync(otherPlatformDirPath);
                    console.log(otherPlatformDirPath);
                }
            } catch (e) {
                console.warn(e);
            }
        }
    }
})

