# lunar-cli


```
npm install @snapmaker/snapmaker-lunar
```
